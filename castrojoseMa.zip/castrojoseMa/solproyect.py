
import time 
inicio=time.time()
def valid(n, r, acum):
    if n in acum:
        return acum[n]
    cont = [0] * 10
    for digit in str(n):
        cont[int(digit)] += 1
        if cont[int(digit)] > r:
            acum[n] = False
            return False
    acum[n] = True
    return True

def duo(C, R):
    parejas = []
    acum = {} 
    for den in range(1000, 99999):
        if valid(den, R, acum) and '0' not in str(den):
            num = den * C
            mid = str(den) + str(num)
            if valid(mid, R, acum) and  10000 <= num < 99999:
                parejas.append((den, num))
    return parejas
t = int(input(" "))
for _ in range(t):
    C, R = map(int, input(" ").split())
    parejas = duo(C, R)
    for den, num in parejas:
        print(f"{num}/{den}={C}")

print(time.time()-inicio)